package com.example.macstudent.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.jk.login.R;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnLogin;
    Button btnReg;
    EditText edtEmail;
    EditText edtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);
        btnReg= findViewById(R.id.btnReg);
        btnReg.setOnClickListener(this);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
    }

    @Override
    public void onClick(View view) {

        if (view.getId() == btnLogin.getId()){
            String username = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();

            if (username.equals("mad@summer.com") && password.equals("qwer")){
                Toast.makeText(this,"Login Successful",Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(this,"Invalid username/password",Toast.LENGTH_LONG).show();
            }


        }else if(view.getId() == btnReg.getId()){
            Toast.makeText(this,"Register clicked",Toast.LENGTH_LONG).show();
        }


        Intent signupIntent = new Intent(this,SignUpActivity.class);
        startActivity(signupIntent);
    }
}
